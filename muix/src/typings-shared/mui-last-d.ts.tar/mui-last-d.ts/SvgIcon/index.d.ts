export { default } from './SvgIcon';
export * from './SvgIcon';
