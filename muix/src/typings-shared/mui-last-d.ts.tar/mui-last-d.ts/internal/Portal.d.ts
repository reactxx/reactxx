import * as React from 'react';

export interface PortalProps {
  open?: boolean;
}

export default class Portal extends React.Component<PortalProps> {}
