export function cloneChildrenWithClassName<T>(
  children: React.ReactNode,
  className: string
): T[];
