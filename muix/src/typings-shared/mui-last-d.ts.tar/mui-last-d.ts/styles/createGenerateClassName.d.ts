/**
   * FIXME: `jss` TS typings are bad and incomplete ...
   *        So the following typigns are not really good.
   */
export default function createGenerateClassName(): (
  rule: Object,
  stylesheet?: Object
) => string;
