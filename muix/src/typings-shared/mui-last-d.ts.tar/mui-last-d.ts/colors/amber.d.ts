import { Color } from '..';

declare const color: Color;

export default color;
