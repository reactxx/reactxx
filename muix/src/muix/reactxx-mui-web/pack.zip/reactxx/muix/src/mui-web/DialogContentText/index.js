export { default } from './DialogContentText';
