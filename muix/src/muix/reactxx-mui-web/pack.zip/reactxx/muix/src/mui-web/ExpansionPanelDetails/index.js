export { default } from './ExpansionPanelDetails';
