export { default } from './Tooltip';
