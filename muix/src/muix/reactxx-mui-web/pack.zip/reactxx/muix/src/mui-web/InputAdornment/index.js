export { default } from './InputAdornment';
