export { default } from './DialogActions';
