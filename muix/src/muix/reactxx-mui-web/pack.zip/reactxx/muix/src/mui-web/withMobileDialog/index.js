export { default } from './withMobileDialog';
