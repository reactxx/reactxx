const shape = {
  borderRadius: 4,
};

export default shape;
