export { default } from './CardMedia';
