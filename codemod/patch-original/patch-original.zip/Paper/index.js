export { default } from './Paper';
