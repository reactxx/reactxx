export { default } from './TableFooter';
