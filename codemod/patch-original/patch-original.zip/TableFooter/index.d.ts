export { default } from './TableFooter';
export * from './TableFooter';
