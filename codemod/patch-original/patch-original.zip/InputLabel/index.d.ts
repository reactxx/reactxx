export { default } from './InputLabel';
export * from './InputLabel';
