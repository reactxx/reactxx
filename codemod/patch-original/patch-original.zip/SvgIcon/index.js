export { default } from './SvgIcon';
