export interface CommonColors {
  black: string;
  white: string;
}

declare const common: CommonColors;
export default common;
