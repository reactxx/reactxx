module.exports = {
  rules: {
    'import/no-mutable-exports': 'off',
    'max-len': 'off',
  },
};
